
addEventListener('fetch', event => {
  event.respondWith(handleRequest(event.request))
})


async function handleRequest(request) { 
	const cookie = request.headers.get('cookie')
	const url = "https://cfw-takehome.developers.workers.dev/api/variants"
	let resp_1 = await fetch(url);
	if (resp_1.ok) {
  		let json = await resp_1.json();
  		if (cookie){
				console.log('HERE')
  				if (cookie.includes('ab_test=0')){
  					let ab_test0 = await fetch(json['variants'][0]);
  					var response = new Response(ab_test0.body, ab_test0)
  					return response
  					
  				}else {
  					let ab_test1 = await fetch(json['variants'][1]);
  					var response = new Response(ab_test1.body, ab_test1)
  					return response	
  				}
  		//if there is a cookie there, we check which link we need to make the request
  		//to, index 0(A) or 1(B)	
		} else{
			index = Math.floor(Math.random() * 2);
  			const chosen_url = json['variants'][index]
  			let resp_2 = await fetch(chosen_url);
  			if (resp_2.ok){
				var response = new Response(resp_2.body, resp_2)
  				response.headers.append('Set-Cookie', `ab_test=${index}; path=/`)
  				return response	
			} else {
				alert("HTTP-Error: " + resp_2.status);
  				return new Response("HTTP-Error: " + resp_2.status, 
  								{headers: { 'content-type': 'text/plain' }, })
			}
		}
		//else we find a random number and set the cookie to whatever random number
		//we chose
	} else {
  		alert("HTTP-Error: " + resp_1.status);
  		return new Response("HTTP-Error: " + resp_1.status, 
  							{headers: { 'content-type': 'text/plain' }, })
	}
}
